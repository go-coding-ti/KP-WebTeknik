<?php
header(‘Location: public/’);
?>